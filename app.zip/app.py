#!/usr/bin/env python3

from flask import Flask
from markupsafe import escape
import markdown
import markdown.extensions.fenced_code
from flask import render_template
from jinja2 import Environment, PackageLoader, BaseLoader, FileSystemLoader






app = Flask(__name__)
app.jinja_env = Environment(loader=FileSystemLoader(searchpath='templates/'), comment_start_string='/*', comment_end_string='*/')

@app.route("/")
def hello_world():
	return "<p>hello World</p>"


#@app.route("/mysql")
#def mysql_sqli():
#	sqli_notes = open("mysql.md", "r")
#	md_render = markdown.markdown(sqli_notes.read(), extensions=["fenced_code"])
#	return md_render


@app.route("/sqli/mysql")
def mysql_sqli():
	return render_template('mysql.html')


@app.route("/sqli")
def sqli():
	return render_template('readme.html')


@app.route("/sqli/mssql")
def mssql_sqli():
	return render_template('mssql.html')

@app.route("/sqli/oricle_sqli")
def oricle_sqli():
	return render_template("oricle.html")


@app.route("/sqli/postgresql")
def postgresql_sqli():
	return render_template('postgre.html')


@app.route("/sqli/sqlite")
def sqlite_sqli():
	return render_template('sqlite.html')


@app.route("/sqli/cassandra")
def cassandra_sqli():
	return render_template('Cassandra.html')

@app.route("/sqli/h2")
def h2_sqli():
	return render_template('h2.html')


@app.route("/sqli/db2")
def db2_sqli():
	return render_template('db2.html')

@app.route("/sqli/big-query")
def bigquery_sqli():
	return render_template('bigquery.html')


@app.route("/fi")
def fi_vulns():
	return render_template('fi.html')


@app.route("/command-injection")
def os_injection():
	return render_template('cmd-injection.html')


@app.route("/xss")
def xss_vuln():
	return render_template('xss.html')


@app.route("/ssrf")
def ssrf_vuln():
	return render_template('ssrf.html')


@app.route("/xxe")
def xxe_vuln():
	return render_template('xxe.html')


@app.route("/dir-travel")
def dir_travel_vuln():
	return render_template('dir-travel.html')


#@app.route("/ssti")
#def ssti_vuln():
#	return render_template('ssti.html')																						